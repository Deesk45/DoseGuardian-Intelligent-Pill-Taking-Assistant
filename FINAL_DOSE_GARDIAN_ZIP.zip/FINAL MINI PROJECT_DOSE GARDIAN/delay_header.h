#include"types.h"

void delay_us(u32);
void delay_ms(u32);
void delay_s(u32);
