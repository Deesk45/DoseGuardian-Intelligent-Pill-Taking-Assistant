#include"types.h"

s8 LUT[][4]={'7','8','9','<',
						 '4','5','6','>',	
						 '1','2','3','U',
					   '%','0','#','D'};
#define R0 16
#define R1 17
#define R2 18
#define R3 19
#define C0 20
#define C1 21
#define C2 22
#define C3 23
